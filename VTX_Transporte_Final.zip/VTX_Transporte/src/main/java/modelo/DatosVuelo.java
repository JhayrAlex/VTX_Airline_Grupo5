package modelo;

/**
 *
 * @author edani
 */
public class DatosVuelo {
    // Selección de Ida
    public static boolean esRedondo = false;
    public static String horaIda = "";
    public static String asientoIda = "";
    public static String claseIda = ""; // Premium o Economy
    public static String tipoVuelo = ""; // Aquí guardaremos "Ida" o "Redondo"

    // Selección de Vuelta
    public static String horaVuelta = "";
    public static String asientoVuelta = "";
    public static String claseVuelta = "";
    
    // Usuario
    public static String nombrePasajero = "";
    
}