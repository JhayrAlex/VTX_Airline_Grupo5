package util;

import java.util.Arrays;
import java.util.List;

public class Constantes {
    
    public static final List<String> PAISES_VALIDOS = Arrays.asList(
        "ECUADOR",
        "ESTADOS UNIDOS",
        "MEXICO",
        "CANADA",
        "ARGENTINA",
        "COLOMBIA"
    );
    
}
